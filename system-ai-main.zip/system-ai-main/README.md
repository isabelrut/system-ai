# system-ai
As part of thesis project. 
